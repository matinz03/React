import React from "react";
import ReactDOM from "react-dom";

ReactDOM.render(
  <div>
    <h1>My Favourite Foods</h1>
    <img
      src="https://www.allrecipes.com/thmb/ZyYXwx4FKm3Y13OJGpUjVwx8Ftg=/1500x0/filters:no_upscale():max_bytes(150000):strip_icc()/3882376-bacon-for-the-family-or-a-crowd-sanzoe-4x3-1-8711ddbb6af242f184a79e5e72efc7e3.jpg"
      alt=""
    />
    <img
      src="https://meatnbone.com/cdn/shop/products/jamon-de-cebo-100percent-iberico-or-just-carved-meat-n-bone.jpg?v=1696506375"
      alt=""
    />
    <img
      src="https://www.allrecipes.com/thmb/2rPJp4sRMmSa-5MgBRuHz8XDxlc=/1500x0/filters:no_upscale():max_bytes(150000):strip_icc()/233446-lo-mein-noodles-dmfs-2x1-1356-1490-62771eb9cd6840fdb75f332303fff7b1.jpg"
      alt=""
    />
  </div>,
  document.getElementById("root")
);
